<!-- begin:: Content -->
<home v-show="menu==0"></home>
<person v-if="menu==1"></person>
<!-- end:: Content -->
