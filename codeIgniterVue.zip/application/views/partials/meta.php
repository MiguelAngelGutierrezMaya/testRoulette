<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">

<?php
$meta = array(
	array(
		'name' => 'viewport',
		'content' => 'width=device-width, initial-scale=1'
	),
);

echo meta($meta);
?>
