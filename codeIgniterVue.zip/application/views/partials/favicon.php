<?php
	
	/*
		favicon
	*/
	echo link_tag('assets/img/favicon.ico', 'shortcut icon', 'image/ico');
